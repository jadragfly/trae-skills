# -*- coding: utf-8 -*-
"""
TRAE 技能打包工具
自动化打包技能文件夹，排除虚拟环境，验证 SKILL.md 格式

功能：
  1. 自动检测和排除 .venv, .bg_env, node_modules 等大型文件夹
  2. 验证 SKILL.md 是否存在且格式正确
  3. 显示详细的打包统计信息
  4. 支持批量打包多个技能
  5. 丰富的错误检查和友好提示
"""

import os
import sys
import shutil
import traceback
from pathlib import Path
import re

# 全局调试开关
DEBUG_MODE = False


def debug_print(*args, **kwargs):
    """调试输出函数，只有 DEBUG_MODE 为 True 时才输出"""
    if DEBUG_MODE:
        print("[DEBUG]", *args, **kwargs)


# 需要排除的文件夹模式
EXCLUDE_PATTERNS = [
    '.venv',
    'venv',
    '.bg_env',
    'env',
    '.env',
    'node_modules',
    '__pycache__',
    '.git',
    '.svn',
    '.hg',
    '.idea',
    '.vscode',
    '*.pyc',
    '*.pyo',
    '*.so',
    '*.dll',
    '*.dylib',
    '.DS_Store',
    'Thumbs.db',
    '.cache',
    '.pytest_cache',
    '.tox',
    'dist',
    'build',
    '*.egg-info'
]


def is_excluded(path: Path) -> bool:
    """
    检查路径是否应该被排除
    
    参数:
        path: 文件或文件夹路径
        
    返回:
        True 如果应该排除，False 否则
    """
    path_str = str(path)
    
    for pattern in EXCLUDE_PATTERNS:
        if pattern.startswith('*.'):
            # 文件扩展名模式
            ext = pattern[1:]
            if path_str.endswith(ext):
                return True
        else:
            # 文件夹/文件名模式
            if pattern in path_str.split(os.sep):
                return True
    
    return False


def check_yaml_format(content: str) -> dict:
    """
    检查 YAML 格式是否正确
    
    参数:
        content: SKILL.md 文件内容
        
    返回:
        包含检查结果的字典
    """
    result = {
        'valid': False,
        'name': None,
        'description': None,
        'errors': []
    }
    
    # 检查是否以 --- 开头
    if not content.strip().startswith('---'):
        result['errors'].append('SKILL.md 必须以 YAML front matter (---) 开头')
        return result
    
    # 检查是否有结束的 ---
    if content.count('---') < 2:
        result['errors'].append('SKILL.md 必须有结束的分隔符 (---)')
        return result
    
    # 提取 YAML 部分
    lines = content.split('\n')
    yaml_lines = []
    in_yaml = False
    yaml_end_found = False
    
    for i, line in enumerate(lines):
        if line.strip() == '---':
            if not in_yaml:
                in_yaml = True
                continue
            else:
                yaml_end_found = True
                break
        
        if in_yaml:
            yaml_lines.append(line)
    
    if not yaml_end_found:
        result['errors'].append('YAML front matter 未正确闭合')
        return result
    
    yaml_content = '\n'.join(yaml_lines)
    
    # 检查必需字段
    if not re.search(r'^name:\s*.+', yaml_content, re.MULTILINE):
        result['errors'].append('缺少 name 字段')
    else:
        name_match = re.search(r'^name:\s*(.+)', yaml_content, re.MULTILINE)
        result['name'] = name_match.group(1).strip()
    
    if not re.search(r'^description:\s*.+', yaml_content, re.MULTILINE):
        result['errors'].append('缺少 description 字段')
    else:
        desc_match = re.search(r'^description:\s*(.+)', yaml_content, re.MULTILINE)
        result['description'] = desc_match.group(1).strip()
    
    if not result['errors']:
        result['valid'] = True
    
    return result


def analyze_skill_directory(skill_path: Path) -> dict:
    """
    分析技能目录，返回详细信息
    
    参数:
        skill_path: 技能目录路径
        
    返回:
        包含分析结果的字典
    """
    debug_print(f"分析目录: {skill_path}")
    
    result = {
        'path': str(skill_path),
        'name': skill_path.name,
        'exists': skill_path.exists(),
        'is_dir': skill_path.is_dir() if skill_path.exists() else False,
        'skill_md_exists': False,
        'skill_md_valid': False,
        'skill_md_info': None,
        'files': [],
        'excluded_files': [],
        'total_size': 0,
        'excluded_size': 0,
        'errors': [],
        'warnings': []
    }
    
    if not result['exists']:
        result['errors'].append(f"目录不存在: {skill_path}")
        return result
    
    if not result['is_dir']:
        result['errors'].append(f"路径不是目录: {skill_path}")
        return result
    
    # 检查 SKILL.md
    skill_md_path = skill_path / 'SKILL.md'
    if skill_md_path.exists():
        result['skill_md_exists'] = True
        
        try:
            with open(skill_md_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            yaml_result = check_yaml_format(content)
            result['skill_md_valid'] = yaml_result['valid']
            result['skill_md_info'] = yaml_result
            
            if not yaml_result['valid']:
                result['errors'].extend(yaml_result['errors'])
            else:
                result['name'] = yaml_result['name']
                debug_print(f"✓ SKILL.md 验证通过: {yaml_result['name']}")
                
        except Exception as e:
            result['errors'].append(f"读取 SKILL.md 失败: {e}")
    else:
        result['errors'].append('缺少 SKILL.md 文件')
        result['warnings'].append('建议添加 SKILL.md 文件以正确配置技能')
    
    # 遍历所有文件
    all_files = []
    for root, dirs, files in os.walk(skill_path):
        # 过滤要排除的目录
        dirs[:] = [d for d in dirs if not is_excluded(Path(root) / d)]
        
        for file in files:
            file_path = Path(root) / file
            
            if is_excluded(file_path):
                try:
                    file_size = file_path.stat().st_size
                    result['excluded_files'].append({
                        'path': str(file_path.relative_to(skill_path)),
                        'size': file_size
                    })
                    result['excluded_size'] += file_size
                except:
                    pass
            else:
                try:
                    file_size = file_path.stat().st_size
                    result['files'].append({
                        'path': str(file_path.relative_to(skill_path)),
                        'size': file_size
                    })
                    result['total_size'] += file_size
                except:
                    pass
    
    # 按大小排序显示
    result['files'].sort(key=lambda x: x['size'], reverse=True)
    result['excluded_files'].sort(key=lambda x: x['size'], reverse=True)
    
    return result


def create_skill_package(skill_path: Path, output_path: Path = None) -> dict:
    """
    创建技能打包文件
    
    参数:
        skill_path: 技能目录路径
        output_path: 输出文件路径（可选）
        
    返回:
        包含打包结果的字典
    """
    debug_print(f"开始打包技能: {skill_path}")
    
    result = {
        'success': False,
        'skill_path': str(skill_path),
        'output_path': None,
        'analysis': None,
        'errors': [],
        'message': ''
    }
    
    # 分析目录
    analysis = analyze_skill_directory(skill_path)
    result['analysis'] = analysis
    
    if analysis['errors']:
        result['errors'].extend(analysis['errors'])
        result['message'] = '分析失败'
        return result
    
    # 生成输出文件名
    if output_path is None:
        output_path = skill_path.parent / f"{skill_path.name}.zip"
    
    # 如果已存在，询问是否覆盖
    if output_path.exists():
        print(f"警告: 输出文件已存在: {output_path}")
        print("将覆盖原文件")
    
    try:
        # 创建 zip 文件
        import zipfile
        
        debug_print(f"创建打包文件: {output_path}")
        
        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for file_info in analysis['files']:
                file_path = skill_path / file_info['path']
                arcname = file_info['path']  # 打包后的文件名
                zipf.write(file_path, arcname)
                debug_print(f"  添加: {arcname} ({file_info['size']} bytes)")
        
        result['success'] = True
        result['output_path'] = str(output_path)
        result['message'] = f"打包成功！输出文件: {output_path}"
        
        # 添加文件计数信息
        result['file_count'] = len(analysis['files'])
        result['total_size'] = analysis['total_size']
        
    except Exception as e:
        result['errors'].append(f"打包失败: {e}")
        result['message'] = '打包失败'
        if DEBUG_MODE:
            traceback.print_exc()
    
    return result


def batch_pack_skills(skill_paths: list, output_dir: Path = None) -> dict:
    """
    批量打包多个技能
    
    参数:
        skill_paths: 技能目录路径列表
        output_dir: 输出目录（可选）
        
    返回:
        包含批量打包结果的字典
    """
    results = {
        'total': len(skill_paths),
        'success': 0,
        'failed': 0,
        'results': []
    }
    
    for skill_path in skill_paths:
        print(f"\n{'='*60}")
        print(f"打包技能: {skill_path}")
        print('='*60)
        
        result = create_skill_package(Path(skill_path))
        results['results'].append(result)
        
        if result['success']:
            results['success'] += 1
            print(f"✓ {result['message']}")
        else:
            results['failed'] += 1
            print(f"✗ 打包失败:")
            for error in result['errors']:
                print(f"  - {error}")
    
    print(f"\n{'='*60}")
    print(f"批量打包完成: 成功 {results['success']}/{results['total']}")
    print('='*60)
    
    return results


class SkillPackager:
    """技能打包工具类"""
    
    def __init__(self, skill_path: str):
        """
        初始化打包工具
        
        参数:
            skill_path: 技能目录路径
        """
        self.skill_path = Path(skill_path)
        self.analysis = None
        self.result = None
    
    def analyze(self) -> dict:
        """分析技能目录"""
        self.analysis = analyze_skill_directory(self.skill_path)
        return self.analysis
    
    def validate(self) -> tuple:
        """
        验证技能是否有效
        
        返回:
            (is_valid, errors) 元组
        """
        if self.analysis is None:
            self.analyze()
        
        errors = []
        
        if not self.analysis['exists']:
            errors.append("技能目录不存在")
        
        if not self.analysis['is_dir']:
            errors.append("路径不是目录")
        
        if not self.analysis['skill_md_exists']:
            errors.append("缺少 SKILL.md 文件")
        elif not self.analysis['skill_md_valid']:
            errors.extend(self.analysis['skill_md_info']['errors'])
        
        return (len(errors) == 0, errors)
    
    def package(self, output_path: str = None) -> dict:
        """
        打包技能
        
        参数:
            output_path: 输出文件路径（可选）
            
        返回:
            打包结果字典
        """
        is_valid, errors = self.validate()
        
        if not is_valid:
            return {
                'success': False,
                'errors': errors,
                'message': '技能验证失败'
            }
        
        if output_path:
            output_path = Path(output_path)
        
        self.result = create_skill_package(self.skill_path, output_path)
        return self.result
    
    def print_report(self):
        """打印详细报告"""
        if self.analysis is None:
            self.analyze()
        
        print("\n" + "="*60)
        print("技能分析报告")
        print("="*60)
        
        # 基本信息
        print(f"\n技能名称: {self.analysis['name']}")
        print(f"技能路径: {self.analysis['path']}")
        print(f"目录存在: {'是' if self.analysis['exists'] else '否'}")
        
        # SKILL.md 状态
        print(f"\nSKILL.md:")
        print(f"  - 文件存在: {'是' if self.analysis['skill_md_exists'] else '否'}")
        if self.analysis['skill_md_exists']:
            print(f"  - 格式验证: {'通过' if self.analysis['skill_md_valid'] else '失败'}")
            if self.analysis['skill_md_info']:
                info = self.analysis['skill_md_info']
                if info['name']:
                    print(f"  - 技能名称: {info['name']}")
                if info['description']:
                    desc = info['description']
                    print(f"  - 技能描述: {desc[:80]}{'...' if len(desc) > 80 else ''}")
        
        # 文件统计
        print(f"\n文件统计:")
        print(f"  - 待打包文件数: {len(self.analysis['files'])}")
        print(f"  - 待打包总大小: {self.analysis['total_size'] / 1024:.2f} KB")
        print(f"  - 排除文件数: {len(self.analysis['excluded_files'])}")
        print(f"  - 排除总大小: {self.analysis['excluded_size'] / 1024 / 1024:.2f} MB")
        
        # 主要文件列表
        if self.analysis['files']:
            print(f"\n待打包文件列表 (前10个):")
            for i, file_info in enumerate(self.analysis['files'][:10], 1):
                size_kb = file_info['size'] / 1024
                print(f"  {i}. {file_info['path']} ({size_kb:.2f} KB)")
        
        # 排除的文件
        if self.analysis['excluded_files']:
            print(f"\n排除的文件/文件夹 (前10个):")
            for i, file_info in enumerate(self.analysis['excluded_files'][:10], 1):
                size_mb = file_info['size'] / 1024 / 1024
                print(f"  {i}. {file_info['path']} ({size_mb:.2f} MB)")
        
        # 错误和警告
        if self.analysis['errors']:
            print(f"\n错误:")
            for error in self.analysis['errors']:
                print(f"  ✗ {error}")
        
        if self.analysis['warnings']:
            print(f"\n警告:")
            for warning in self.analysis['warnings']:
                print(f"  ⚠ {warning}")
        
        print("\n" + "="*60)


def execute(inputs: dict) -> dict:
    """
    技能执行入口
    
    参数:
        inputs: 输入参数字典，包含:
            - skill_path: 技能目录路径
            - output_path: 输出文件路径（可选）
            - batch: 是否批量模式
            - skill_paths: 批量模式的技能路径列表
            - analyze_only: 仅分析不打包
            - debug: 是否开启调试模式
    
    返回:
        结果字典
    """
    global DEBUG_MODE
    
    skill_path = inputs.get('skill_path')
    output_path = inputs.get('output_path')
    batch_mode = inputs.get('batch', False)
    skill_paths = inputs.get('skill_paths', [])
    analyze_only = inputs.get('analyze_only', False)
    DEBUG_MODE = inputs.get('debug', False)
    
    debug_print(f"输入参数: {inputs}")
    
    try:
        if batch_mode and skill_paths:
            # 批量模式
            results = batch_pack_skills(skill_paths)
            return {
                'success': results['success'] > 0,
                'message': f"批量打包完成，成功 {results['success']}/{results['total']}",
                'results': results
            }
        elif skill_path:
            # 单个技能模式
            packager = SkillPackager(skill_path)
            packager.analyze()
            packager.print_report()
            
            if analyze_only:
                return {
                    'success': True,
                    'message': '分析完成',
                    'analysis': packager.analysis
                }
            
            result = packager.package(output_path)
            
            if result['success']:
                print(f"\n✓ 打包成功！")
                print(f"  输出文件: {result['output_path']}")
                print(f"  文件数量: {result['file_count']}")
                print(f"  总大小: {result['total_size'] / 1024:.2f} KB")
            else:
                print(f"\n✗ 打包失败:")
                for error in result['errors']:
                    print(f"  - {error}")
            
            return result
        else:
            return {
                'success': False,
                'message': '缺少必要参数：请提供 skill_path 或 batch + skill_paths'
            }
    
    except Exception as e:
        return {
            'success': False,
            'message': f"执行失败：{e}",
            'errors': [str(e)]
        }


def main():
    """命令行接口"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='TRAE 技能打包工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
功能说明:
  1. 自动检测和排除虚拟环境 (.venv, .bg_env, node_modules 等)
  2. 验证 SKILL.md 是否存在且包含正确的 YAML 格式
  3. 显示详细的打包统计信息
  4. 支持批量打包多个技能

使用示例:
  # 分析技能目录
  python skill.py --skill-path ./my-skill --analyze-only

  # 打包单个技能
  python skill.py --skill-path ./my-skill

  # 指定输出文件
  python skill.py --skill-path ./my-skill --output ./my-skill.zip

  # 批量打包
  python skill.py --batch --skill-paths ./skill1 ./skill2 ./skill3

  # 开启调试模式
  python skill.py --skill-path ./my-skill --debug

注意事项:
  - 打包时会自动排除虚拟环境文件夹
  - SKILL.md 必须包含 YAML front matter (---...---)
  - YAML 中必须包含 name 和 description 字段
        """
    )
    
    parser.add_argument('--skill-path', help='技能目录路径（单文件模式）')
    parser.add_argument('--output', '--output-path', dest='output_path', help='输出文件路径')
    parser.add_argument('--batch', action='store_true', help='批量打包模式')
    parser.add_argument('--skill-paths', nargs='+', help='技能路径列表（批量模式）')
    parser.add_argument('--analyze-only', action='store_true', help='仅分析，不打包')
    parser.add_argument('--debug', action='store_true', help='开启调试模式')
    
    args = parser.parse_args()
    
    inputs = {
        'skill_path': args.skill_path,
        'output_path': args.output_path,
        'batch': args.batch,
        'skill_paths': args.skill_paths,
        'analyze_only': args.analyze_only,
        'debug': args.debug
    }
    
    result = execute(inputs)
    
    print("\n" + "="*60)
    print("执行结果")
    print("="*60)
    print(f"成功: {result.get('success')}")
    print(f"消息: {result.get('message')}")
    
    if 'analysis' in result:
        print(f"\n分析结果:")
        analysis = result['analysis']
        print(f"  - SKILL.md 存在: {'是' if analysis['skill_md_exists'] else '否'}")
        print(f"  - YAML 格式正确: {'是' if analysis['skill_md_valid'] else '否'}")
        print(f"  - 待打包文件: {len(analysis['files'])}")
        print(f"  - 排除文件: {len(analysis['excluded_files'])}")
    
    if 'errors' in result and result['errors']:
        print(f"\n错误:")
        for error in result['errors']:
            print(f"  - {error}")


if __name__ == "__main__":
    main()
