# 技能打包工具

自动化打包 TRAE 技能文件夹，支持验证 SKILL.md 格式、自动排除虚拟环境、批量打包等功能。

## 核心功能

- ✅ **SKILL.md 验证** - 检查 YAML 格式是否正确
- 🚫 **智能排除** - 自动排除 .venv, .bg_env, node_modules 等大型文件夹
- 📊 **详细统计** - 显示文件数量、大小统计
- 📦 **批量打包** - 支持同时打包多个技能
- 🔍 **分析模式** - 仅分析不打包，查看技能配置

## 快速开始

### 方式一：一键启动（推荐）

```bash
# 进入技能目录
cd skill_打包技能

# 打包单个技能
python run_skill.py --skill-path ../其他技能

# 仅分析技能配置
python run_skill.py --skill-path ../其他技能 --analyze-only
```

### 方式二：手动运行

```bash
# 使用系统 Python
python skill.py --skill-path ./your-skill

# 或创建虚拟环境
python -m venv .venv
.venv\Scripts\activate  # Windows
source .venv/bin/activate  # Linux/Mac
python skill.py --skill-path ./your-skill
```

## 命令行参数

| 参数 | 说明 | 示例 |
|------|------|------|
| `--skill-path <path>` | 技能目录路径 | `--skill-path ./my-skill` |
| `--output <path>` | 输出文件路径 | `--output ./my-skill.zip` |
| `--analyze-only` | 仅分析不打包 | `--analyze-only` |
| `--batch` | 批量打包模式 | `--batch` |
| `--skill-paths <paths>` | 技能路径列表 | `--skill-paths ./s1 ./s2` |
| `--debug` | 开启调试模式 | `--debug` |

## SKILL.md 验证

自动检查 SKILL.md 是否包含正确的 YAML front matter：

```yaml
---
name: 技能名称
description: 技能描述
---
```

**验证项目：**
- ✅ 文件是否存在
- ✅ 是否以 `---` 开头
- ✅ 是否包含结束 `---`
- ✅ 是否包含 `name` 字段
- ✅ 是否包含 `description` 字段

## 自动排除的文件

- `.venv` / `venv` - Python 虚拟环境
- `.bg_env` - 自定义虚拟环境
- `.env` / `env` - 环境变量文件
- `node_modules` - Node.js 依赖
- `__pycache__` - Python 缓存
- `.git` / `.svn` / `.hg` - 版本控制
- `.idea` / `.vscode` - 编辑器配置
- `*.pyc` / `*.pyo` - Python 编译文件
- `.DS_Store` / `Thumbs.db` - 系统文件

## 使用示例

### 示例 1：分析技能配置

```bash
python run_skill.py --skill-path ../背景移除技能 --analyze-only
```

### 示例 2：打包技能

```bash
# 默认输出到同目录 .zip 文件
python run_skill.py --skill-path ../背景移除技能

# 指定输出文件
python run_skill.py --skill-path ../背景移除技能 --output ../背景移除技能.zip
```

### 示例 3：批量打包

```bash
python run_skill.py --batch --skill-paths ../s1 ../s2 ../s3
```

## 系统要求

- Python 3.8+
- Windows / Linux / macOS
- uv（可选）

## 依赖

此工具只使用 Python 标准库，无需额外依赖：
- os, sys, shutil, traceback - 文件和目录操作
- pathlib - 路径操作
- re - 正则表达式
- zipfile - ZIP 文件操作
- subprocess - 子进程管理

## 常见问题

### Q: 缺少 SKILL.md 文件

确保技能目录包含 SKILL.md 文件，包含 YAML front matter。

### Q: YAML 格式不正确

确保 SKILL.md 格式正确：
```yaml
---
name: 技能名称
description: 技能描述
---
```

### Q: 打包文件太大

技能打包工具会自动排除虚拟环境文件夹。如果仍然太大，检查是否有其他大型文件夹。

## 许可证

MIT License
