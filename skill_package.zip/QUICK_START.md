# 技能打包工具 - 快速使用指南

## 📍 技能位置

```
d:/impotent/solo/eco/skill_打包技能/
```

## 🚀 快速使用

### 一键运行（自动管理环境）

```bash
# 进入技能目录
cd d:/impotent/solo/eco/skill_打包技能

# 分析技能配置（推荐先分析）
python run_skill.py --skill-path ../背景移除技能 --analyze-only

# 打包技能
python run_skill.py --skill-path ../背景移除技能
```

## 📋 包含文件

- `skill.py` - 核心功能代码
- `run_skill.py` - 环境管理脚本
- `requirements.txt` - 依赖列表（仅标准库）
- `README.md` - 完整文档
- `SKILL.md` - 技能配置

## ✨ 核心功能

1. **SKILL.md 验证** - 自动检查 YAML 格式
2. **智能排除** - 自动排除虚拟环境
3. **详细统计** - 显示文件和大小信息
4. **批量打包** - 支持多个技能

## 🎯 常用命令

```bash
# 分析技能配置
python run_skill.py --skill-path ../your-skill --analyze-only

# 打包技能
python run_skill.py --skill-path ../your-skill

# 指定输出文件
python run_skill.py --skill-path ../your-skill --output ../your-skill.zip

# 批量打包
python run_skill.py --batch --skill-paths ../s1 ../s2 ../s3

# 调试模式
python run_skill.py --skill-path ../your-skill --debug
```

## ⚠️ 常见错误及解决方案

### 错误 1: 缺少 SKILL.md 文件

```
错误: 缺少 SKILL.md 文件
```

**解决方案：** 在技能目录添加 SKILL.md 文件：
```yaml
---
name: 你的技能名称
description: 你的技能描述
---
```

### 错误 2: YAML 格式不正确

```
错误: SKILL.md 必须以 YAML front matter (---) 开头
错误: 缺少 name 字段
```

**解决方案：** 确保 SKILL.md 以 `---` 开头，包含 `name` 和 `description`：
```yaml
---
name: 技能名称
description: 技能描述
---

# 技能标题

这里是技能说明...
```

## 📊 典型输出示例

### 分析模式输出

```
技能分析报告
============================================================

技能名称: 背景移除技能
技能路径: D:\skills\背景移除技能
目录存在: 是

SKILL.md:
  - 文件存在: 是
  - 格式验证: 通过
  - 技能名称: 背景移除技能
  - 技能描述: 使用 AI 模型自动移除图片背景...

文件统计:
  - 待打包文件数: 6
  - 待打包总大小: 13.25 KB
  - 排除文件数: 1
  - 排除总大小: 364.58 MB
```

### 打包模式输出

```
============================================================
打包技能: D:\skills\背景移除技能
============================================================

技能分析报告
...

✓ 打包成功！
  输出文件: D:\skills\背景移除技能.zip
  文件数量: 6
  总大小: 13.25 KB
```

## 🔧 高级用法

### 批量处理多个技能

```bash
# 创建一个技能列表文件
echo "../skill1" > skills.txt
echo "../skill2" >> skills.txt
echo "../skill3" >> skills.txt

# 读取文件批量打包
for /f %i in (skills.txt) do python run_skill.py --skill-path %i
```

### 自动化工作流

```bash
# 1. 分析所有技能
python run_skill.py --skill-path ../背景移除技能 --analyze-only
python run_skill.py --skill-path ../视频生成 --analyze-only
python run_skill.py --skill-path ../文档处理 --analyze-only

# 2. 批量打包
python run_skill.py --batch \
  --skill-paths \
  ../背景移除技能 \
  ../视频生成 \
  ../文档处理

# 3. 验证打包结果
unzip -l ../背景移除技能.zip
```

## 📚 详细文档

查看 `README.md` 获取完整使用说明和 API 文档。
