---
name: 技能打包工具
description: 自动化打包 TRAE 技能文件夹，支持验证 SKILL.md 格式、自动排除虚拟环境、批量打包等功能。当用户想要打包、上传、分享技能，或需要检查技能配置是否正确时使用此工具。
---

# 技能打包工具

自动化打包 TRAE 技能文件夹，提供完整的错误检查和统计信息。

## 功能特点

- ✅ **SKILL.md 验证** - 检查 YAML 格式是否正确
- 🚫 **智能排除** - 自动排除 .venv, .bg_env, node_modules 等大型文件夹
- 📊 **详细统计** - 显示文件数量、大小统计
- 📦 **批量打包** - 支持同时打包多个技能
- 🔍 **分析模式** - 仅分析不打包，查看技能配置
- 🎯 **友好提示** - 提供详细的错误和警告信息

## 使用方式

### 一键启动（推荐）

```bash
# 进入技能目录
cd skill_打包技能

# 打包单个技能
python run_skill.py --skill-path ../其他技能

# 仅分析技能配置
python run_skill.py --skill-path ../其他技能 --analyze-only
```

### 命令行参数

| 参数 | 说明 | 示例 |
|------|------|------|
| `--skill-path <path>` | 技能目录路径 | `--skill-path ./my-skill` |
| `--output <path>` | 输出文件路径 | `--output ./my-skill.zip` |
| `--analyze-only` | 仅分析不打包 | `--analyze-only` |
| `--batch` | 批量打包模式 | `--batch` |
| `--skill-paths <paths>` | 技能路径列表 | `--skill-paths ./s1 ./s2` |
| `--debug` | 开启调试模式 | `--debug` |

## 核心功能

### 1. SKILL.md 验证

自动检查 SKILL.md 是否包含正确的 YAML front matter：

```yaml
---
name: 技能名称
description: 技能描述
---
```

**验证项目：**
- ✅ 文件是否存在
- ✅ 是否以 `---` 开头
- ✅ 是否包含结束 `---`
- ✅ 是否包含 `name` 字段
- ✅ 是否包含 `description` 字段

### 2. 智能排除

自动排除以下文件和文件夹：

- `.venv` / `venv` - Python 虚拟环境
- `.bg_env` - 自定义虚拟环境
- `.env` / `env` - 环境变量文件
- `node_modules` - Node.js 依赖
- `__pycache__` - Python 缓存
- `.git` / `.svn` / `.hg` - 版本控制
- `.idea` / `.vscode` - 编辑器配置
- `*.pyc` / `*.pyo` - Python 编译文件
- `.DS_Store` / `Thumbs.db` - 系统文件

### 3. 详细统计

打包时显示：
- 待打包文件数量和大小
- 排除的文件数量和大小
- 主要文件列表
- SKILL.md 验证结果

## 使用示例

### 示例 1：分析技能配置

```bash
# 分析技能目录，不打包
python run_skill.py --skill-path ../背景移除技能 --analyze-only
```

输出示例：
```
技能分析报告
============================================================

技能名称: 背景移除技能
SKILL.md: 存在 ✓, 格式正确 ✓
文件统计:
  - 待打包文件数: 6
  - 待打包总大小: 13.25 KB
  - 排除文件数: 1
  - 排除总大小: 364.58 MB
```

### 示例 2：打包技能

```bash
# 打包技能，默认输出到同目录 .zip 文件
python run_skill.py --skill-path ../背景移除技能

# 指定输出文件
python run_skill.py --skill-path ../背景移除技能 --output ../背景移除技能.zip
```

### 示例 3：批量打包

```bash
# 批量打包多个技能
python run_skill.py --batch \
  --skill-paths ../背景移除技能 ../视频生成 ../文档处理
```

### 示例 4：调试模式

```bash
# 查看详细日志
python run_skill.py --skill-path ../背景移除技能 --debug
```

## 常见问题

### Q: 缺少 SKILL.md 文件

```
错误: 缺少 SKILL.md 文件
警告: 建议添加 SKILL.md 文件以正确配置技能
```

**解决方案：** 在技能目录添加 SKILL.md 文件，包含 YAML front matter。

### Q: YAML 格式不正确

```
错误: SKILL.md 必须以 YAML front matter (---) 开头
错误: 缺少 name 字段
错误: 缺少 description 字段
```

**解决方案：** 确保 SKILL.md 以 `---` 开头，包含 `name` 和 `description` 字段。

### Q: 打包文件太大

**原因：** 可能包含了虚拟环境文件夹。

**解决方案：** 确保使用正确的打包方式，技能打包工具会自动排除：
- `.venv`
- `.bg_env`
- `venv`
- 其他常见虚拟环境文件夹

### Q: 如何验证打包结果？

```bash
# 解压并检查文件列表
unzip -l your-skill.zip

# 验证 SKILL.md 存在
unzip -p your-skill.zip SKILL.md | head -5
```

## 系统要求

- Python 3.8+
- Windows / Linux / macOS
- uv（可选，用于创建虚拟环境）

## 返回结果

分析模式：
```json
{
    "success": true,
    "message": "分析完成",
    "analysis": {
        "name": "技能名称",
        "skill_md_exists": true,
        "skill_md_valid": true,
        "files": [...],
        "total_size": 12345
    }
}
```

打包模式：
```json
{
    "success": true,
    "message": "打包成功！输出文件: skill.zip",
    "output_path": "skill.zip",
    "file_count": 6,
    "total_size": 12345
}
```

## 注意事项

1. 打包前会自动分析技能目录
2. 虚拟环境会自动排除，无需手动处理
3. 建议先使用 `--analyze-only` 检查配置
4. 输出文件默认保存在技能目录的同级目录
5. 如果输出文件已存在，会提示覆盖

## 版本历史

### 1.0.0 (2026-05-19)
- ✨ 初始版本发布
- ✅ SKILL.md YAML 格式验证
- ✅ 智能排除虚拟环境
- ✅ 详细统计信息
- ✅ 批量打包支持
- ✅ 调试模式

## 许可证

MIT License
