# -*- coding: utf-8 -*-
"""
自动环境管理脚本 - UV 版本
使用 uv 创建虚拟环境并安装依赖，避免 Windows netrc 编码问题

关键改进：
  1. 使用 uv 代替 pip，避免 netrc 编码问题
  2. 使用清华镜像源加速下载
  3. 自动检测和创建虚拟环境
  4. 完善的错误处理和提示
"""

import os
import sys
import subprocess
from pathlib import Path
import platform


def get_script_directory():
    """获取脚本所在目录（技能目录）"""
    return Path(__file__).resolve().parent


def get_venv_python(venv_path):
    """获取虚拟环境中的 Python 解释器路径"""
    if platform.system() == "Windows":
        return venv_path / "Scripts" / "python.exe"
    else:
        return venv_path / "bin" / "python"


def check_uv_available():
    """检查 uv 是否可用"""
    try:
        result = subprocess.run(
            ["uv", "--version"],
            capture_output=True,
            text=True,
            timeout=5
        )
        return result.returncode == 0
    except Exception:
        return False


def check_venv_exists(venv_path):
    """检查虚拟环境是否已存在且可用"""
    python_exe = get_venv_python(venv_path)
    
    if not python_exe.exists():
        print(f"虚拟环境不存在: {venv_path}")
        return False
    
    try:
        result = subprocess.run(
            [str(python_exe), "--version"],
            capture_output=True,
            timeout=5
        )
        return result.returncode == 0
    except Exception as e:
        print(f"检查虚拟环境时出错: {e}")
        return False


def check_dependencies_installed(venv_path):
    """检查依赖是否已安装"""
    python_exe = get_venv_python(venv_path)
    
    try:
        result = subprocess.run(
            [str(python_exe), "-c", 
             "import rembg; import PIL; import onnxruntime; import requests; print('OK')"],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        if result.returncode == 0 and "OK" in result.stdout:
            print("✓ 所有依赖已安装")
            return True
        else:
            print("⚠ 部分依赖未安装或有问题")
            return False
            
    except Exception as e:
        print(f"检查依赖时出错: {e}")
        return False


def create_venv_with_uv(venv_path):
    """
    使用 uv 创建虚拟环境
    
    参数:
        venv_path: 虚拟环境路径
        
    返回:
        bool: 是否成功
    """
    print("=" * 60)
    print("使用 uv 创建虚拟环境")
    print("=" * 60)
    print(f"脚本目录: {get_script_directory()}")
    print(f"虚拟环境位置: {venv_path}")
    print()
    
    try:
        # 使用 uv 创建虚拟环境
        result = subprocess.run(
            ["uv", "venv", str(venv_path)],
            capture_output=True,
            text=True,
            timeout=60
        )
        
        if result.returncode == 0:
            print("✓ 虚拟环境创建成功")
            return True
        else:
            print(f"✗ 虚拟环境创建失败")
            print(f"  错误信息: {result.stderr}")
            return False
            
    except subprocess.TimeoutExpired:
        print("✗ 创建虚拟环境超时")
        return False
    except Exception as e:
        print(f"✗ 创建虚拟环境时出错: {e}")
        return False


def install_requirements_with_uv(venv_path, requirements_file):
    """
    使用 uv 安装依赖
    
    参数:
        venv_path: 虚拟环境路径
        requirements_file: requirements.txt 文件路径
        
    返回:
        bool: 是否成功
    """
    python_exe = get_venv_python(venv_path)
    
    print()
    print("=" * 60)
    print("使用 uv 安装依赖")
    print("=" * 60)
    print(f"Python: {python_exe}")
    print(f"依赖文件: {requirements_file}")
    print()
    
    try:
        # 使用 uv pip install，指定清华镜像源
        print("正在安装依赖包（使用清华镜像源）...")
        install_result = subprocess.run(
            [
                "uv", "pip", "install",
                "--python", str(python_exe),
                "-r", str(requirements_file),
                "--index-url", "https://pypi.tuna.tsinghua.edu.cn/simple"
            ],
            capture_output=True,
            text=True,
            timeout=600
        )
        
        if install_result.returncode == 0:
            print("✓ 依赖安装成功")
            
            # 显示安装的包
            if install_result.stdout:
                lines = install_result.stdout.strip().split('\n')
                for line in lines[-10:]:  # 只显示最后10行
                    print(f"  {line}")
            
            return True
        else:
            print(f"✗ 依赖安装失败")
            print(f"  错误信息: {install_result.stderr}")
            return False
            
    except subprocess.TimeoutExpired:
        print("✗ 安装超时（超过10分钟）")
        return False
    except Exception as e:
        print(f"✗ 安装依赖时出错: {e}")
        return False


def run_skill_with_venv(venv_path, skill_args):
    """
    在虚拟环境中运行技能
    
    参数:
        venv_path: 虚拟环境路径
        skill_args: 传递给 skill.py 的参数
        
    返回:
        bool: 是否成功
    """
    python_exe = get_venv_python(venv_path)
    skill_file = get_script_directory() / "skill.py"
    
    if not skill_file.exists():
        print(f"错误：找不到 skill.py 文件: {skill_file}")
        return False
    
    try:
        print()
        print("=" * 60)
        print("运行技能")
        print("=" * 60)
        print(f"Python: {python_exe}")
        print(f"技能文件: {skill_file}")
        print(f"参数: {' '.join(skill_args)}")
        print()
        
        result = subprocess.run(
            [str(python_exe), str(skill_file)] + skill_args,
            capture_output=False,
            cwd=os.getcwd()
        )
        
        return result.returncode == 0
        
    except Exception as e:
        print(f"✗ 运行技能时出错: {e}")
        return False


def main():
    """主函数"""
    print("=" * 60)
    print("背景移除技能 - UV 环境管理")
    print("=" * 60)
    print()
    print(f"当前工作目录: {os.getcwd()}")
    print(f"脚本目录: {get_script_directory()}")
    print(f"Python 版本: {sys.version}")
    print()
    
    # 检查 uv 是否可用
    if not check_uv_available():
        print("⚠ 警告：uv 不可用")
        print("  请先安装 uv：")
        print("  Windows: pip install uv")
        print("  或参考: https://github.com/astral-sh/uv#installation")
        print()
        print("备选方案：使用标准虚拟环境")
        print("  python -m venv .venv")
        print("  .venv\\Scripts\\activate")
        print("  pip install -r requirements.txt")
        print()
    
    # 技能目录
    skill_dir = get_script_directory()
    venv_path = skill_dir / ".bg_env"  # 使用 .bg_env 作为环境名
    requirements_file = skill_dir / "requirements.txt"
    
    # 检查是否已创建虚拟环境
    if not check_venv_exists(venv_path):
        print("虚拟环境不存在，开始创建...")
        
        if check_uv_available():
            if not create_venv_with_uv(venv_path):
                print("✗ 无法创建虚拟环境")
                sys.exit(1)
        else:
            print("使用标准 venv...")
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "venv", str(venv_path)],
                    capture_output=True,
                    text=True
                )
                if result.returncode != 0:
                    print(f"✗ 创建失败: {result.stderr}")
                    sys.exit(1)
                print("✓ 虚拟环境创建成功")
            except Exception as e:
                print(f"✗ 创建虚拟环境时出错: {e}")
                sys.exit(1)
        
        # 安装依赖
        if check_uv_available():
            if not install_requirements_with_uv(venv_path, requirements_file):
                print("✗ 无法安装依赖")
                sys.exit(1)
        else:
            print("使用 pip 安装依赖...")
            pip_exe = venv_path / "Scripts" / "pip.exe" if platform.system() == "Windows" else venv_path / "bin" / "pip"
            try:
                result = subprocess.run(
                    [str(pip_exe), "install", "-r", str(requirements_file), 
                     "-i", "https://pypi.tuna.tsinghua.edu.cn/simple"],
                    capture_output=True,
                    text=True,
                    timeout=600
                )
                if result.returncode != 0:
                    print(f"✗ 安装失败: {result.stderr}")
                    sys.exit(1)
                print("✓ 依赖安装成功")
            except Exception as e:
                print(f"✗ 安装依赖时出错: {e}")
                sys.exit(1)
    else:
        print("✓ 虚拟环境已存在")
        
        # 检查依赖
        if not check_dependencies_installed(venv_path):
            print()
            print("重新安装依赖...")
            
            if check_uv_available():
                if not install_requirements_with_uv(venv_path, requirements_file):
                    print("✗ 无法安装依赖")
                    sys.exit(1)
            else:
                pip_exe = venv_path / "Scripts" / "pip.exe" if platform.system() == "Windows" else venv_path / "bin" / "pip"
                try:
                    result = subprocess.run(
                        [str(pip_exe), "install", "-r", str(requirements_file),
                         "-i", "https://pypi.tuna.tsinghua.edu.cn/simple"],
                        capture_output=True,
                        text=True,
                        timeout=600
                    )
                    if result.returncode != 0:
                        print(f"✗ 安装失败: {result.stderr}")
                        sys.exit(1)
                    print("✓ 依赖安装成功")
                except Exception as e:
                    print(f"✗ 安装依赖时出错: {e}")
                    sys.exit(1)
    
    # 传递所有命令行参数
    skill_args = sys.argv[1:]
    
    if skill_args:
        # 运行技能
        if run_skill_with_venv(venv_path, skill_args):
            sys.exit(0)
        else:
            sys.exit(1)
    else:
        print()
        print("=" * 60)
        print("✓ 环境准备完成")
        print("=" * 60)
        print()
        print("使用方式:")
        print(f"  python {Path(__file__).name} --input your_image.png")
        print(f"  python {Path(__file__).name} --batch --input-dir ./images")
        print()
        print("或者直接使用虚拟环境中的 Python:")
        print(f"  {get_venv_python(venv_path)} skill.py --help")
        print()
        print("虚拟环境位置:")
        print(f"  {venv_path}")
        print()
        print("激活虚拟环境:")
        if platform.system() == "Windows":
            print(f"  .venv\\Scripts\\activate")
        else:
            print(f"  source .venv/bin/activate")


if __name__ == "__main__":
    main()
