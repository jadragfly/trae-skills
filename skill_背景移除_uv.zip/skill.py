# -*- coding: utf-8 -*-
"""
TRAE 背景移除技能 - UV 版本
提供图片背景移除功能的技能接口
使用 uv 管理虚拟环境，避免 Windows netrc 编码问题

关键改进：
  1. 使用 uv 创建和管理虚拟环境
  2. 自动处理 netrc 编码问题
  3. 支持多种 AI 模型
  4. 提供单文件和批量处理模式
"""

import os
import sys
import shutil
import traceback
from pathlib import Path

# 全局调试开关
DEBUG_MODE = False


def debug_print(*args, **kwargs):
    """调试输出函数，只有 DEBUG_MODE 为 True 时才输出"""
    if DEBUG_MODE:
        print("[DEBUG]", *args, **kwargs)


# 模型配置
MODEL_CONFIGS = {
    "u2netp": {
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2netp.onnx",
        "size": "4.2 MB",
        "description": "轻量版模型，速度快，适合快速处理",
        "expected_size": 4 * 1024 * 1024
    },
    "u2net": {
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2net.onnx",
        "size": "167.8 MB",
        "description": "标准版模型，质量均衡",
        "expected_size": 167 * 1024 * 1024
    },
    "u2net_human_seg": {
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2net_human_seg.onnx",
        "size": "167.8 MB",
        "description": "人像专用模型，适合人物照片",
        "expected_size": 167 * 1024 * 1024
    },
    "silueta": {
        "url": "https://github.com/danielgatis/rembg/releases/download/v0.0.0/silueta.onnx",
        "size": "43.6 MB",
        "description": "小型模型，平衡速度与质量",
        "expected_size": 43 * 1024 * 1024
    }
}


def get_model_dir():
    """
    获取模型存储目录
    
    返回:
        Path 对象，表示模型存储目录
    """
    model_dir = Path.home() / ".trae" / "models" / "remove_bg"
    model_dir.mkdir(parents=True, exist_ok=True)
    return model_dir


def is_model_complete(model_name, file_path):
    """
    检查模型文件是否完整
    
    参数:
        model_name: 模型名称
        file_path: 文件路径
    
    返回:
        True 如果文件完整，False 否则
    """
    if not file_path.exists():
        return False
    
    file_size = file_path.stat().st_size
    expected_size = MODEL_CONFIGS.get(model_name, {}).get('expected_size', 1024 * 1024)
    
    return file_size >= expected_size * 0.9


def find_model(model_name):
    """
    查找模型文件位置
    
    参数:
        model_name: 模型名称
    
    返回:
        (模型文件完整路径, 所在目录路径) 或 (None, None)
    """
    model_filename = f"{model_name}.onnx"
    
    search_paths = [
        get_model_dir(),
        Path.home() / ".u2net",
        Path(__file__).parent.resolve(),
        Path(".").resolve(),
    ]
    
    debug_print("开始搜索模型文件: %s" % model_filename)
    
    for search_path in search_paths:
        model_path = search_path / model_filename
        debug_print("检查路径: %s" % model_path)
        if model_path.exists() and model_path.is_file():
            file_size = model_path.stat().st_size
            debug_print("找到模型: %s (大小: %d bytes / %.2f MB)" % (model_path, file_size, file_size/1024/1024))
            
            if is_model_complete(model_name, model_path):
                debug_print("模型文件验证通过")
                return str(model_path), str(search_path)
            else:
                expected_size = MODEL_CONFIGS.get(model_name, {}).get('expected_size', 1024 * 1024)
                debug_print("模型文件不完整 (期望: %.2f MB, 实际: %.2f MB)" % (
                    expected_size / 1024 / 1024, file_size / 1024 / 1024))
    
    debug_print("未找到有效的模型文件: %s" % model_filename)
    return None, None


def download_model(model_name, timeout=600):
    """
    下载模型文件
    
    参数:
        model_name: 模型名称
        timeout: 下载超时时间（秒）
        
    返回:
        模型文件路径（成功）或 None（失败）
    """
    try:
        import requests
    except ImportError:
        print("错误：缺少 requests 库，请安装：pip install requests")
        return None
    
    model_info = MODEL_CONFIGS.get(model_name)
    if not model_info:
        print("错误：未知模型: %s" % model_name)
        return None
    
    model_dir = get_model_dir()
    model_path = model_dir / f"{model_name}.onnx"
    
    if is_model_complete(model_name, model_path):
        debug_print("模型已存在且完整，跳过下载")
        return str(model_path)
    
    if model_path.exists():
        debug_print("删除不完整的模型文件")
        model_path.unlink()
    
    url = model_info['url']
    
    print("正在下载模型: %s" % model_name)
    print("  URL: %s" % url)
    print("  大小: %s" % model_info['size'])
    print("  保存到: %s" % model_path)
    print("")
    
    try:
        os.environ['NETRC'] = ''
        
        response = requests.get(url, stream=True, timeout=timeout)
        response.raise_for_status()
        
        total_size = int(response.headers.get('content-length', 0))
        downloaded_size = 0
        
        with open(model_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded_size += len(chunk)
                    
                    if total_size > 0:
                        progress = (downloaded_size / total_size) * 100
                        sys.stdout.write('\r  进度: %.1f%% (%d/%d MB)' % (
                            progress,
                            downloaded_size // (1024 * 1024),
                            total_size // (1024 * 1024)
                        ))
                        sys.stdout.flush()
        
        print("\n")
        
        if is_model_complete(model_name, model_path):
            print("OK! 模型下载成功")
            return str(model_path)
        else:
            print("警告：模型下载可能不完整")
            model_path.unlink()
            return None
            
    except requests.exceptions.RequestException as e:
        print("错误：下载失败：%s" % e)
        if model_path.exists():
            model_path.unlink()
        return None


def setup_model_environment(model_name="u2net"):
    """
    设置模型环境变量
    
    参数:
        model_name: 模型名称
    
    返回:
        是否成功找到/设置模型
    """
    debug_print("尝试查找现有模型...")
    model_path, model_dir = find_model(model_name)
    
    if model_dir:
        os.environ['U2NET_HOME'] = model_dir
        debug_print("使用已有模型，U2NET_HOME=%s" % model_dir)
        return True
    
    print("未找到模型文件，开始自动下载...")
    downloaded_path = download_model(model_name)
    
    if downloaded_path:
        model_dir = str(Path(downloaded_path).parent)
        os.environ['U2NET_HOME'] = model_dir
        debug_print("使用下载的模型，U2NET_HOME=%s" % model_dir)
        return True
    
    print("")
    print("自动下载失败，请手动下载模型文件：")
    model_info = MODEL_CONFIGS.get(model_name)
    if model_info:
        print("  URL: %s" % model_info['url'])
        print("  大小: %s" % model_info['size'])
        print("  保存到: %s" % (get_model_dir() / f"{model_name}.onnx"))
    
    return False


class RemoveBgSkill:
    """背景移除技能类"""
    
    def __init__(self, model_name="u2net"):
        """
        初始化技能
        
        参数:
            model_name: 使用的模型名称，可选: u2netp, u2net, u2net_human_seg, silueta
        """
        os.environ['NETRC'] = ''
        
        self.model_name = model_name
        debug_print("使用模型: %s" % model_name)
        
        if not setup_model_environment(model_name):
            raise Exception("未找到模型文件且自动下载失败，请手动下载模型")
        
        debug_print("技能初始化完成")
    
    def remove_background(self, input_path, output_path=None):
        """
        移除图片背景
        
        参数:
            input_path: 输入图片路径
            output_path: 输出图片路径，如果为 None 则自动生成
        
        返回:
            输出文件路径（成功）或 None（失败）
        """
        try:
            from rembg import remove
        except ImportError as e:
            print("错误：缺少必要的库，请先安装：pip install rembg pillow onnxruntime")
            print("详细信息：%s" % e)
            return None
        
        input_file = Path(input_path)
        if not input_file.exists():
            print("错误：输入文件不存在：%s" % input_path)
            return None
        
        if output_path is None:
            output_path = input_file.parent / ("%s_no_bg.png" % input_file.stem)
        
        debug_print("输入文件：%s" % input_file)
        debug_print("输出文件：%s" % output_path)
        debug_print("模型目录：%s" % os.environ.get('U2NET_HOME', 'N/A'))
        
        try:
            with open(input_file, 'rb') as i:
                input_data = i.read()
            
            debug_print("正在移除背景...")
            
            output_data = remove(input_data)
            
            with open(output_path, 'wb') as o:
                o.write(output_data)
            
            print("OK! 背景移除成功！")
            print("  输出文件：%s" % output_path)
            
            return str(output_path)
            
        except Exception as e:
            print("错误：处理图片时发生错误：%s" % e)
            if DEBUG_MODE:
                traceback.print_exc()
            return None
    
    def batch_remove_background(self, input_dir, output_dir=None):
        """
        批量移除文件夹中所有图片的背景
        
        参数:
            input_dir: 输入文件夹路径
            output_dir: 输出文件夹路径，如果为 None 则在输入文件夹下创建 no_bg 子文件夹
        
        返回:
            成功处理的文件数量
        """
        input_folder = Path(input_dir)
        if not input_folder.exists():
            print("错误：输入文件夹不存在：%s" % input_dir)
            return 0
        
        supported_formats = {'.png', '.jpg', '.jpeg', '.webp', '.bmp'}
        
        image_files = [f for f in input_folder.iterdir() 
                       if f.is_file() and f.suffix.lower() in supported_formats]
        
        if not image_files:
            print("警告：在 %s 中未找到支持的图片文件" % input_dir)
            return 0
        
        if output_dir is None:
            output_folder = input_folder / "no_bg"
        else:
            output_folder = Path(output_dir)
        
        output_folder.mkdir(exist_ok=True)
        
        debug_print("找到 %d 张图片" % len(image_files))
        debug_print("输出文件夹：%s" % output_folder)
        
        success_count = 0
        for i, image_file in enumerate(image_files, 1):
            print("[%d/%d] 处理：%s" % (i, len(image_files), image_file.name))
            output_path = output_folder / ("%s_no_bg.png" % image_file.stem)
            
            if self.remove_background(str(image_file), str(output_path)):
                success_count += 1
        
        print("")
        print("完成！成功处理 %d/%d 张图片" % (success_count, len(image_files)))
        print("输出目录：%s" % output_folder)
        
        return success_count


def execute(inputs):
    """
    技能执行入口
    
    参数:
        inputs: 输入参数字典，包含:
            - input_path: 输入图片路径（单文件模式）
            - output_path: 输出图片路径（可选）
            - batch: 是否批量处理模式
            - input_dir: 输入文件夹路径（批量模式）
            - output_dir: 输出文件夹路径（批量模式，可选）
            - model: 模型名称（可选，默认 u2net）
            - debug: 是否开启调试模式
    
    返回:
        结果字典
    """
    global DEBUG_MODE
    
    input_path = inputs.get('input_path')
    output_path = inputs.get('output_path')
    batch_mode = inputs.get('batch', False)
    input_dir = inputs.get('input_dir')
    output_dir = inputs.get('output_dir')
    model_name = inputs.get('model', 'u2net')
    DEBUG_MODE = inputs.get('debug', False)
    
    debug_print("输入参数: %s" % inputs)
    
    try:
        skill = RemoveBgSkill(model_name=model_name)
    except Exception as e:
        return {
            'success': False,
            'message': "初始化技能失败：%s" % str(e)
        }
    
    try:
        if batch_mode and input_dir:
            count = skill.batch_remove_background(input_dir, output_dir)
            return {
                'success': count > 0,
                'message': "批量处理完成，成功处理 %d 张图片" % count,
                'count': count
            }
        elif input_path:
            result_path = skill.remove_background(input_path, output_path)
            return {
                'success': result_path is not None,
                'message': "背景移除成功" if result_path else "背景移除失败",
                'output_path': result_path
            }
        else:
            return {
                'success': False,
                'message': "缺少必要参数：请提供 input_path（单文件）或 input_dir（批量）"
            }
    except Exception as e:
        return {
            'success': False,
            'message': "执行失败：%s" % str(e)
        }


def main():
    """命令行接口"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='TRAE 背景移除技能 - UV 版本',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python skill.py --input i.png                    # 处理单张图片
  python skill.py --input i.png --output out.png   # 指定输出文件
  python skill.py --batch --input-dir ./images     # 批量处理文件夹
  python skill.py --model u2netp --input i.png    # 使用轻量模型
  python skill.py --debug --input i.png            # 开启调试模式
  
支持的模型:
  - u2netp:    4.2 MB, 轻量版，速度快（推荐）
  - u2net:     167.8 MB, 标准版，质量均衡（默认）
  - u2net_human_seg: 167.8 MB, 人像专用
  - silueta:   43.6 MB, 平衡速度与质量

特点:
  1. 使用 uv 管理虚拟环境，避免 Windows netrc 编码问题
  2. 自动下载模型文件
  3. 支持批量处理
  4. 调试模式可查看详细日志
        """
    )
    
    parser.add_argument('--input', help='输入图片路径（单文件模式）')
    parser.add_argument('--output', help='输出图片路径')
    parser.add_argument('--batch', action='store_true', help='批量处理模式')
    parser.add_argument('--input-dir', help='输入文件夹路径（批量模式）')
    parser.add_argument('--output-dir', help='输出文件夹路径（批量模式）')
    parser.add_argument('--model', default='u2net', help='模型名称')
    parser.add_argument('--debug', action='store_true', help='开启调试模式')
    
    args = parser.parse_args()
    
    inputs = {
        'input_path': args.input,
        'output_path': args.output,
        'batch': args.batch,
        'input_dir': args.input_dir,
        'output_dir': args.output_dir,
        'model': args.model,
        'debug': args.debug
    }
    
    result = execute(inputs)
    
    print("")
    print("=== 执行结果 ===")
    print("成功: %s" % result.get('success'))
    print("消息: %s" % result.get('message'))
    if 'output_path' in result:
        print("输出路径: %s" % result.get('output_path'))
    if 'count' in result:
        print("处理数量: %d" % result.get('count'))


if __name__ == "__main__":
    main()
