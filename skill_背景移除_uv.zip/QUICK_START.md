# 背景移除技能 - 快速使用指南

## 📍 技能位置

```
d:/impotent/solo/eco/skill_背景移除_uv/
```

## 🚀 快速使用

### 一键运行（自动管理环境）

```bash
# 进入技能目录
cd d:/impotent/solo/eco/skill_背景移除_uv

# 处理单张图片
python run_skill.py --input your_image.png

# 批量处理
python run_skill.py --batch --input-dir ./images

# 使用特定模型
python run_skill.py --input photo.jpg --model u2net_human_seg
```

## 📋 包含文件

- `skill.py` - 核心功能代码
- `run_skill.py` - 环境管理脚本（使用 uv）
- `requirements.txt` - 依赖列表
- `README.md` - 完整文档

## ✨ 核心特性

- 使用 **uv** 管理虚拟环境，避免 Windows netrc 编码问题
- 自动下载 AI 模型
- 支持 4 种模型：u2netp, silueta, u2net, u2net_human_seg
- 支持批量处理
- 使用清华镜像源加速

## 🎯 常用命令

```bash
# 基础使用
python run_skill.py --input photo.png

# 指定输出文件
python run_skill.py --input photo.png --output result.png

# 轻量模型（推荐，速度快）
python run_skill.py --input photo.png --model u2netp

# 人像专用模型
python run_skill.py --input portrait.png --model u2net_human_seg

# 批量处理
python run_skill.py --batch --input-dir ./photos

# 调试模式
python run_skill.py --debug --input photo.png
```

## 🔧 环境说明

- **虚拟环境位置**: `.bg_env/`
- **Python 版本**: 3.12.11
- **主要依赖**: rembg, pillow, onnxruntime

## 📚 详细文档

查看 `README.md` 获取完整使用说明和 API 文档。
