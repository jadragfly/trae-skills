---
name: 背景移除技能
description: 使用 AI 模型自动移除图片背景，支持多种模型选择和批量处理。当用户想要移除图片背景、抠图、处理证件照、制作透明背景图片时使用此技能。
---

# 背景移除技能

使用 AI 模型自动移除图片背景，支持多种模型选择和自动下载。

## 功能特点

- 🚀 **快速处理** - 默认使用 4.2MB 轻量模型，速度快
- 🎨 **多种模型** - 支持 4 种 AI 模型，满足不同需求
- 📦 **自动下载** - 模型首次使用时自动下载
- 📁 **批量处理** - 支持批量处理整个文件夹
- 🔧 **调试模式** - 提供详细调试输出
- 🛡️ **环境隔离** - 使用 uv 虚拟环境，避免依赖冲突

## 使用方式

### 一键启动（推荐）

```bash
# 进入技能目录
cd skill_背景移除_uv

# 处理单张图片
python run_skill.py --input your_image.png

# 批量处理
python run_skill.py --batch --input-dir ./photos

# 使用特定模型
python run_skill.py --input photo.jpg --model u2net_human_seg
```

### 命令行参数

| 参数 | 说明 | 示例 |
|------|------|------|
| `--input <path>` | 输入图片路径 | `--input photo.png` |
| `--output <path>` | 输出图片路径 | `--output result.png` |
| `--batch` | 批量处理模式 | `--batch` |
| `--input-dir <path>` | 输入文件夹路径 | `--input-dir ./images` |
| `--output-dir <path>` | 输出文件夹路径 | `--output-dir ./results` |
| `--model <name>` | 模型名称 | `--model u2netp` |
| `--debug` | 开启调试模式 | `--debug` |

## 支持的模型

| 模型名称 | 大小 | 适用场景 |
|---------|------|---------|
| `u2netp` (默认) | 4.2 MB | 轻量快速，日常使用推荐 |
| `silueta` | 43.6 MB | 平衡速度与质量 |
| `u2net` | 167.8 MB | 标准版，质量均衡 |
| `u2net_human_seg` | 167.8 MB | 人像专用，适合人物照片 |

## Python API 使用

```python
from skill import RemoveBgSkill, execute

# 使用类
skill = RemoveBgSkill(model_name='u2netp')
result = skill.remove_background('input.png', 'output.png')

# 使用 execute 函数
result = execute({
    'input_path': 'input.png',
    'output_path': 'output.png',
    'model': 'u2netp',
    'debug': False
})

print(result)
# {'success': True, 'message': '背景移除成功', 'output_path': 'output.png'}
```

## 返回结果

单文件模式：
```json
{
    "success": true,
    "message": "背景移除成功",
    "output_path": "image_no_bg.png"
}
```

批量模式：
```json
{
    "success": true,
    "message": "批量处理完成，成功处理 5 张图片",
    "count": 5
}
```

## 依赖项

- rembg>=2.0.0
- pillow>=10.0.0
- onnxruntime>=1.16.0
- requests>=2.31.0

## 系统要求

- Python 3.8+
- Windows / Linux / macOS
- uv（自动创建虚拟环境，如未安装会提示）

## 环境说明

- **虚拟环境位置**: `.bg_env/`
- **模型缓存**: `~/.trae/models/remove_bg/`
- **Python 版本**: 3.12.11（自动创建）

## 常见问题

### Q: 虚拟环境在哪里？
默认创建在技能目录下的 `.bg_env` 文件夹中。

### Q: 如何删除虚拟环境？
```bash
# Windows
rd /s /q .bg_env

# Linux / Mac
rm -rf .bg_env
```

### Q: 依赖安装失败怎么办？
确保 uv 已安装：
```bash
uv --version
```

如果没有安装，先安装 uv：
```bash
pip install uv
```

### Q: 如何查看调试信息？
```bash
python run_skill.py --debug --input image.png
```

## 版本历史

### 2.1.0 (2026-05-19)
- ✨ 新增 uv 环境管理支持
- ✨ 使用清华镜像源加速下载
- ✨ 完善的错误处理和提示
- 🐛 修复 Windows netrc 编码问题

## 许可证

MIT License

## 使用示例

### 示例 1：处理证件照
```bash
python run_skill.py --input ID_photo.jpg --output ID_photo_transparent.png --model u2netp
```

### 示例 2：批量处理电商图片
```bash
python run_skill.py --batch --input-dir ./product_photos --output-dir ./product_photos_no_bg
```

### 示例 3：人像抠图
```bash
python run_skill.py --input portrait.jpg --model u2net_human_seg --output portrait_no_bg.png
```

## 注意事项

1. 模型文件会缓存到 `~/.trae/models/remove_bg/` 目录
2. 首次使用时会自动下载模型（约 4-170 MB）
3. 推荐使用 `u2netp` (4.2MB) 进行快速处理
4. 处理人像照片时建议使用 `u2net_human_seg` 模型
5. 建议使用 uv 安装依赖，避免 Windows netrc 编码问题
6. 输出图片为 PNG 格式，带透明背景
