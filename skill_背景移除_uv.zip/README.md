# 背景移除技能 - UV 版本

使用 AI 模型自动移除图片背景，支持多种模型选择。

## 核心特性

- 🚀 **快速处理** - 默认使用 4.2MB 轻量模型，速度快
- 🎨 **多种模型** - 支持 4 种 AI 模型，满足不同需求
- 📦 **自动下载** - 模型首次使用时自动下载
- 📁 **批量处理** - 支持批量处理整个文件夹
- 🔧 **调试模式** - 提供详细调试输出
- 🛡️ **环境隔离** - 使用 uv 虚拟环境，避免依赖冲突

## 支持的模型

| 模型名称 | 大小 | 适用场景 |
|---------|------|---------|
| `u2netp` (默认) | 4.2 MB | 轻量快速，日常使用推荐 |
| `silueta` | 43.6 MB | 平衡速度与质量 |
| `u2net` | 167.8 MB | 标准版，质量均衡 |
| `u2net_human_seg` | 167.8 MB | 人像专用，适合人物照片 |

## 快速开始

### 方式一：一键启动（推荐）⭐

使用 `run_skill.py` 脚本会自动管理虚拟环境，无需手动配置：

```bash
# 首次使用：自动创建虚拟环境并安装依赖
python run_skill.py --input your_image.png

# 后续使用：直接运行，自动跳过已安装的环境
python run_skill.py --batch --input-dir ./images
```

### 方式二：手动管理环境

#### 1. 使用 uv 创建虚拟环境

```bash
# Windows / Linux / Mac
uv venv .bg_env
```

#### 2. 激活虚拟环境

```bash
# Windows
.bg_env\Scripts\activate

# Linux / Mac
source .bg_env/bin/activate
```

#### 3. 安装依赖

```bash
# 使用 uv（推荐，避免 netrc 编码问题）
uv pip install -r requirements.txt --index-url https://pypi.tuna.tsinghua.edu.cn/simple

# 或使用 pip
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

#### 4. 运行技能

```bash
python skill.py --input your_image.png
```

## 命令行参数

| 参数 | 说明 |
|------|------|
| `--input <path>` | 输入图片路径（单文件模式） |
| `--output <path>` | 输出图片路径（默认自动生成） |
| `--batch` | 批量处理模式 |
| `--input-dir <path>` | 输入文件夹路径（批量模式） |
| `--output-dir <path>` | 输出文件夹路径（批量模式） |
| `--model <name>` | 模型名称（默认 u2netp） |
| `--debug` | 开启调试模式 |
| `--list-models` | 列出所有可用模型 |

## 使用示例

### 单张图片处理

```bash
# 基本用法
python run_skill.py --input portrait.png

# 使用人像专用模型
python run_skill.py --input portrait.png --model u2net_human_seg

# 指定输出文件
python run_skill.py --input photo.jpg --output result.png
```

### 批量处理

```bash
# 批量处理整个文件夹
python run_skill.py --batch --input-dir ./photos

# 指定输出目录
python run_skill.py --batch --input-dir ./photos --output-dir ./results
```

### 调试模式

```bash
# 查看详细日志
python run_skill.py --debug --input image.png
```

## Python API 使用

```python
from skill import RemoveBgSkill, execute

# 使用类
skill = RemoveBgSkill(model_name='u2netp')
result = skill.remove_background('input.png', 'output.png')

# 使用 execute 函数
result = execute({
    'input_path': 'input.png',
    'output_path': 'output.png',
    'model': 'u2netp',
    'debug': False
})

print(result)
# {'success': True, 'message': '背景移除成功', 'output_path': 'output.png'}
```

## 返回结果

单文件模式：
```json
{
    "success": true,
    "message": "背景移除成功",
    "output_path": "image_no_bg.png"
}
```

批量模式：
```json
{
    "success": true,
    "message": "批量处理完成，成功处理 5 张图片",
    "count": 5
}
```

## 优势说明

### 为什么使用 uv？

- ✅ **避免 netrc 编码问题** - 在 Windows 系统上，uv 不依赖 netrc 文件，避免编码错误
- ✅ **快速创建环境** - uv 比标准 venv 快 10-100 倍
- ✅ **自动管理依赖** - 自动解析依赖关系，避免冲突
- ✅ **跨平台** - 支持 Windows、Linux、Mac

### 镜像源加速

默认使用清华镜像源（https://pypi.tuna.tsinghua.edu.cn/simple），大幅提升下载速度。

## 常见问题

### Q: 虚拟环境在哪里？

默认创建在技能目录下的 `.bg_env` 文件夹中。

### Q: 如何删除虚拟环境？

```bash
# Windows
rd /s /q .bg_env

# Linux / Mac
rm -rf .bg_env
```

### Q: 依赖安装失败怎么办？

1. 检查 uv 是否安装：
   ```bash
   uv --version
   ```

2. 如果未安装，先安装 uv：
   ```bash
   pip install uv
   ```

3. 手动安装依赖：
   ```bash
   uv pip install -r requirements.txt --index-url https://pypi.tuna.tsinghua.edu.cn/simple
   ```

### Q: 如何查看调试信息？

```bash
python run_skill.py --debug --input image.png
```

### Q: 模型文件在哪里？

模型会自动下载到用户目录：
- Windows: `C:\Users\<用户名>\.trae\models\remove_bg\`
- Linux/Mac: `~/.trae/models/remove_bg/`

## 注意事项

1. 模型文件会缓存到 `~/.trae/models/remove_bg/` 目录
2. 首次使用时会自动下载模型（约 4-170 MB）
3. 推荐使用 `u2netp` (4.2MB) 进行快速处理
4. 处理人像照片时建议使用 `u2net_human_seg` 模型
5. 建议使用 uv 安装依赖，避免 Windows netrc 编码问题

## 版本历史

### 2.1.0 (2026-05-19)
- ✨ 新增 uv 环境管理支持
- ✨ 使用清华镜像源加速下载
- ✨ 完善的错误处理和提示
- 🐛 修复 Windows netrc 编码问题

### 2.0.0
- ✨ 多模型支持
- ✨ 自动下载功能
- ✨ 虚拟环境自动管理

### 1.0.0
- 🚀 初始版本发布

## 许可证

MIT License
